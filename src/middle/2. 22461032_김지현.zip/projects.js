import React, { useState } from 'react';
import design2 from './picture/design2.png';
import design5 from './picture/design5.png';
import codeproject from './picture/codeproject.png';

const projectList = [
  { id: 1, category: 'Plan', title: 'Product planning', thumbnail: design2, description: '굿즈 기획 프로젝트' },
  { id: 2, category: 'Design', title: '3D design', thumbnail: design5, description: '3D 렌더링 프로젝트' },
  { id: 3, category: 'Code', title: 'Game coding', thumbnail: codeproject, description: '슈팅 게임 만들기' },
];

const categories = ['All', 'Plan', 'Design', 'Code'];

const Projects = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedProject, setSelectedProject] = useState(projectList[0]);

  const filtered = selectedCategory === 'All'
    ? projectList
    : projectList.filter(p => p.category === selectedCategory);

  return (
    <div style={styles.container}>
      <div style={styles.categoryRow}>
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            style={{
              ...styles.categoryButton,
              backgroundColor: selectedCategory === cat ? '#b0b0b0' : '#ddd',
              color: selectedCategory === cat ? '#ddd' : 'black'
            }}
          >
            {cat}
          </button>
        ))}
      </div>

      <div style={styles.topSection}>
        <div style={styles.featured}>
          <img src={selectedProject.thumbnail} alt={selectedProject.title} style={styles.featuredImage} />
          <h3>{selectedProject.title}</h3>
        </div>

        <div style={styles.thumbnailList}>
          {filtered.map(project => (
            <img
              key={project.id}
              src={project.thumbnail}
              alt={project.title}
              style={{
                ...styles.thumbnail,
                border: selectedProject.id === project.id ? 'solid 5px #f5eecb' : '2px solid #ccc'
              }}
              onClick={() => setSelectedProject(project)}
            />
          ))}
        </div>
      </div>

      <div style={styles.descriptionBox}>
        <p>{selectedProject.description}</p>
      </div>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '1000px',
    margin: '0 auto',
    padding: '2rem',
    fontFamily: 'sans-serif',
  },
  categoryRow: {
    display: 'flex',
    gap: '1rem',
    marginBottom: '2rem',
  },
  categoryButton: {
    padding: '0.5rem 1rem',
    borderRadius: '20px',
    border: 'none',
    cursor: 'pointer',
  },
  topSection: {
    display: 'flex',
    gap: '2rem',
  },
  featured: {
    flex: 1,
    textAlign: 'center',
  },
  featuredImage: {
    width: '100%',
    objectFit: 'cover',
  },
  thumbnailList: {
    flex: '0 0 200px',
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  },
  thumbnail: {
    width: '100%',
    borderRadius: '6px',
    cursor: 'pointer',
  },
  descriptionBox: {
    marginTop: '2rem',
    backgroundColor: '#f9f9f9',
    padding: '1rem',
    borderRadius: '8px',
  }
};

export default Projects;
